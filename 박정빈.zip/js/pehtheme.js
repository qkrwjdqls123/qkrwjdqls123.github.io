function toggle(){
    let d = document.querySelector(".d1");
    let dc = d.classList;
    if(dc.contains("hidden")){
        dc.remove("hidden");
        dc.add("show");
    }else {
        dc.remove("show");
        dc.add("hidden");
    }
}

function toggle1(){
    let d = document.querySelector(".d2");
    let dc = d.classList;
    if(dc.contains("hidden")){
        dc.remove("hidden");
        dc.add("show");
    }else {
        dc.remove("show");
        dc.add("hidden");
    }
}
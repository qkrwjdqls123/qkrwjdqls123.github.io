function expand_panel_v0(e) {
    let p = e.parentElement.querySelector(".panel");
    p.style.maxHeight = "400px";
}

function expand_panel(e) {
    let allpanel = Array.from(document.querySelectorAll(".panel"));
    let p = e.parentElement.querySelector(".panel");

    for (let i = 0; i < allpanel.length; i++) {
        allpanel[i].style.maxHeight = 0;
    }
    p.style.maxHeight = "400px";
}

function toggle(){
    let d = document.querySelector(".d1");
    let dc = d.classList;
    if(dc.contains("theme1")){
        dc.remove("theme1");
        dc.add("theme2");
    }else {
        dc.remove("theme2");
        dc.add("theme1");
    }
}
